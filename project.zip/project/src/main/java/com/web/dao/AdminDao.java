package com.web.dao;

import java.util.ArrayList;

import com.web.models.Admin;

public interface AdminDao {
	
	boolean  validateAdmin(Admin admin);

}
